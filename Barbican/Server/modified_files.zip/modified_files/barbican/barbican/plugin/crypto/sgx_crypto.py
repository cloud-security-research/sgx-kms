# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import os
import base64

from Crypto.PublicKey import DSA
from Crypto.PublicKey import RSA
from Crypto.Util import asn1
from cryptography import fernet
from oslo_config import cfg
import six

from barbican.common import config
from barbican.common import utils
from barbican import i18n as u
from barbican.plugin.crypto import crypto as c

from sgx import Secret, SGXInterface


CONF = config.new_config()
LOG = utils.getLogger(__name__)

sgx_crypto_plugin_group = cfg.OptGroup(name='sgx_crypto_plugin',
                                          title="SGX Crypto Plugin Options")
sgx_crypto_plugin_opts = [
    cfg.StrOpt('kek',
               default='dGhpcnR5X3R3b19ieXRlX2tleWJsYWhibGFoYmxhaGg=',
               help=u._('Key encryption key to be used by SGX Crypto '
                        'Plugin'), secret=True)
]
CONF.register_group(sgx_crypto_plugin_group)
CONF.register_opts(sgx_crypto_plugin_opts, group=sgx_crypto_plugin_group)
config.parse_args(CONF)

_SIXTEEN_BYTE_KEY = 16

class SGXCryptoPlugin(c.CryptoPluginBase):
    """SGX based implementation of the crypto plugin."""

    def __init__(self, conf=CONF):
        LOG.info("Initializing SGX Crypto")
        self.master_kek = conf.sgx_crypto_plugin.kek
        dir_path = os.path.dirname(os.path.realpath(__file__))
        self.kek_file = os.path.join(dir_path, "masterkey")
        self.context = {}
        self.s_p_ctxt = {}
        self.c_p_net_ctxt = {}
        self.msg_quote = {}
        self.sgx = SGXInterface()
        self.enclave_id = self.sgx.init_enclave(self.sgx.barbie_s)

    def _get_master_key(self):
        sealed_kek = None
        if os.path.exists(self.kek_file):
            sealed_len = self._get_sealed_data_len(_SIXTEEN_BYTE_KEY)
            with open(self.kek_file, 'r') as f:
                kek = f.read()
            sealed_kek = Secret(kek, sealed_len)
        return sealed_kek

    def _get_sealed_data_len(self, plain_len):
        return self.sgx.barbie_c.get_sealed_data_len(self.enclave_id, 0, plain_len)

    def do_attestation(self, data, external_project_id, kek_sk, is_mutual):
        if is_mutual:
            return self._do_mutual_attestation(data, external_project_id, kek_sk)
        else:
            return self._do_attestation(data, external_project_id, kek_sk)

    def _do_attestation(self, data, external_project_id, kek_sk):
        """This method is used for attestation of the server enclave.
        The same method is used for provisioning master kek on server.
        It performs 3 operations based on the msg types in the data
        1. If no msg in data : Generate msg0 & msg1 and return
        2. If msg2 in data : Generate msg3 & return
        3. If msg4 in data : Return session key encrypted with dh key
                             Also returns session key encrypted with kek to be 
                             stored in db, if kek is provisioned.
                             If kek is not provisioned, sealed sk is returned
                             and stored in db which would be used in subsequent
                             provision kek call.
        """
        LOG.info("Call for Attestation")
        if 'msg2' in data:
            msg3 = self.get_msg3(data['msg2'], self.context[external_project_id])
            return { "msg3" : msg3 }, None
        elif 'msg4' in data:
            sealed_dh = self.get_dh_key(data['msg4'], self.context[external_project_id])
            sealed_sk = self._get_or_generate_sk(kek_sk)
            sealed_len = self._get_sealed_data_len(_SIXTEEN_BYTE_KEY)
            dh_sk = self.sgx.transport(self.sgx.barbie_s, self.enclave_id, Secret(sealed_dh, sealed_len), sealed_sk)
            sealed_kek = self._get_master_key()
            if sealed_kek:
                kek_sk = self.sgx.transport(self.sgx.barbie_s, self.enclave_id, sealed_kek, sealed_sk)
                return {"session_key" : dh_sk, "status" : 0}, {'sk' : kek_sk}
            else:
                return {"session_key" : dh_sk, "status" : 0}, {'sk' : sealed_sk.value}
        else:
            msg0 = self.get_msg0()
            ctxt, msg1 = self.get_msg1()
            self.context[external_project_id] = ctxt
            return { "msg0" : msg0, "msg1" : msg1 }, None

    def get_msg0(self):
        ret, msg0 = self.sgx.gen_msg0(self.sgx.barbie_s)
        return msg0

    def get_msg1(self):
        return self.sgx.gen_msg1(self.sgx.barbie_s, self.enclave_id)

    def get_msg2(self, msg0, msg1):
        ret, p_net_ctxt = self.sgx.proc_msg0(self.sgx.barbie_s, msg0)
        msg2 = self.sgx.proc_msg1_gen_msg2(self.sgx.barbie_s, msg1, p_net_ctxt)
        return p_net_ctxt, msg2

    def get_msg3(self, msg2, p_ctxt):
        return self.sgx.proc_msg2_gen_msg3(self.sgx.barbie_s, self.enclave_id,
                msg2, p_ctxt)

    def get_msg4(self, msg3, p_net_ctxt, sealed_sk):
        return self.sgx.proc_msg3_gen_msg4(self.sgx.barbie_s, self.enclave_id,
                msg3, p_net_ctxt, sealed_sk)

    def proc_msg4(self, msg4, p_ctxt):
        status, sk = self.sgx.proc_msg4(self.sgx.barbie_s, self.enclave_id,
                msg4, p_ctxt)
        return sk

    def get_dh_key(self, msg4, ctxt):
        status, sealed_dh = self.sgx.get_dh_key(self.sgx.barbie_s, self.enclave_id,
                msg4, ctxt)
        return sealed_dh

    def _do_mutual_attestation(self, data, external_project_id, kek_sk):
        LOG.info("Call for mutual attestation")
        if all(msg in data for msg in ('c_msg0', 'c_msg1', 's_msg2')):
            s_msg3 = self.get_msg3(data['s_msg2'], self.s_p_ctxt[external_project_id])
            c_p_net_ctxt, c_msg2 = self.get_msg2(data['c_msg0'], data['c_msg1'])
            self.c_p_net_ctxt[external_project_id] = c_p_net_ctxt
            return {"c_msg2" : c_msg2, "s_msg3":s_msg3}, None
        elif all(msg in data for msg in ('c_msg3', 's_msg4')):
            sk = self.proc_msg4(data['s_msg4'], self.s_p_ctxt[external_project_id])
            sealed_sk = self._get_or_generate_sk(kek_sk)
            c_msg4 = self.get_msg4(data['c_msg3'], self.c_p_net_ctxt[external_project_id], sealed_sk)
            sealed_kek = self._get_master_key()
            kek_sk = self.sgx.transport(self.sgx.barbie_s, self.enclave_id, sealed_kek, sealed_sk)
            self.msg_quote[external_project_id] = data['c_msg3']
            if 'policy' in data.keys():
                return {"c_msg4" : c_msg4, "status":"OK"}, {'sk' : kek_sk, 'msg3' : data['c_msg3'], 'policy' : data['policy']}
            else:
                return {"c_msg4" : c_msg4, "status":"OK"}, {'sk' : kek_sk, 'msg3' : data['c_msg3']}
        else:
            s_msg0 = self.get_msg0()
            s_p_ctxt, s_msg1 = self.get_msg1()
            self.s_p_ctxt[external_project_id] = s_p_ctxt
            return { "s_msg0" : s_msg0, "s_msg1" : s_msg1 }, None

    def _get_or_generate_sk(self, kek_sk=None):
        sealed_sk = None
        if kek_sk:
            LOG.info("Using already created session key")
            sealed_kek = self._get_master_key()
            sk = self.sgx.provision_kek(self.sgx.barbie_s, self.enclave_id, sealed_kek, kek_sk)
            sealed_len = self._get_sealed_data_len(_SIXTEEN_BYTE_KEY)
            sealed_sk = Secret(sk, sealed_len)
        else:
            LOG.info("Generating new session key")
            sealed_sk = self.sgx.generate_key(self.sgx.barbie_s, self.enclave_id, _SIXTEEN_BYTE_KEY)
        return sealed_sk

    def get_mr_enclave_signer(self, msg_quote):
        mr_e = self.sgx.get_mr_enclave(msg_quote)
        mr_s = self.sgx.get_mr_signer(msg_quote)
        return mr_e, mr_s

    def compare_buffer(self, buffer1, buffer2, length):
        return self.sgx.compare_secret(self.sgx.barbie_s, buffer1, buffer2, length)

    def do_provision_kek(self, data, external_project_id, sk):
        sealed_len = self._get_sealed_data_len(_SIXTEEN_BYTE_KEY)
        sk = Secret(sk, sealed_len)
        kek = self.sgx.provision_kek(self.sgx.barbie_s, self.enclave_id, sk, data['kek'])
        sealed_kek = Secret(kek, sealed_len)
        with open(self.kek_file, 'w') as f:
            f.write(kek)
        kek_sk = self.sgx.transport(self.sgx.barbie_s, self.enclave_id, sealed_kek, sk)
        return {"status" : "Ok"}, kek_sk

    def encrypt(self, encrypt_dto, kek_meta_dto, project_id):
        unencrypted = encrypt_dto.unencrypted
        session_key = encrypt_dto.session_key
        if not isinstance(unencrypted, six.binary_type):
            raise ValueError(
                u._(
                    'Unencrypted data must be a byte type, but was '
                    '{unencrypted_type}'
                ).format(
                    unencrypted_type=type(unencrypted)
                )
            )
        sealed_kek = self._get_master_key()
        if not sealed_kek:
            raise Exception("Master key is not provisioned. Please contact administrator.")
        kek_secret = None
        if session_key:
            LOG.info("Secret received in encrypted format")
            kek_secret = self.sgx.kek_encrypt(self.enclave_id, session_key, sealed_kek, unencrypted)
        else:
            LOG.info("Secret received in plain format")
            kek_secret = self.sgx.encrypt(self.sgx.barbie_s, self.enclave_id, sealed_kek, Secret(unencrypted, len(unencrypted)))

        return c.ResponseDTO(kek_secret, None)

    def decrypt(self, encrypted_dto, kek_meta_dto, kek_meta_extended,
                project_id):
        encrypted = encrypted_dto.encrypted
        session_key = encrypted_dto.session_key
        sealed_kek = self._get_master_key()
        if not sealed_kek:
            raise Exception("Master key is not provisioned. Please contact administrator.")
        sk_secret = None
        if session_key:
            sk_secret = self.sgx.kek_decrypt(self.enclave_id, session_key, sealed_kek, encrypted)
        else:
            sk_secret = self.sgx.decrypt(self.sgx.barbie_s, self.enclave_id, sealed_kek, encrypted)
            sk_secret = base64.b64decode(sk_secret)
        return sk_secret


    def bind_kek_metadata(self, kek_meta_dto):
        kek_meta_dto.algorithm = 'aes'
        kek_meta_dto.bit_length = 128
        kek_meta_dto.mode = 'gcm'
        if not kek_meta_dto.plugin_meta:
            # the kek is stored encrypted in the plugin_meta field
            encryptor = fernet.Fernet(self.master_kek)
            key = fernet.Fernet.generate_key()
            kek_meta_dto.plugin_meta = encryptor.encrypt(key)
        return kek_meta_dto

    def generate_symmetric(self, generate_dto, kek_meta_dto, project_id):
        byte_length = int(generate_dto.bit_length) // 8
        unencrypted = os.urandom(byte_length)

        return self.encrypt(c.EncryptDTO(unencrypted),
                            kek_meta_dto,
                            project_id)

    def generate_asymmetric(self, generate_dto, kek_meta_dto, project_id):
        """Generate asymmetric keys based on below rules:

        - RSA, with passphrase (supported)
        - RSA, without passphrase (supported)
        - DSA, without passphrase (supported)
        - DSA, with passphrase (not supported)

        Note: PyCrypto is not capable of serializing DSA
        keys and DER formated keys. Such keys will be
        serialized to Base64 PEM to store in DB.

        TODO (atiwari/reaperhulk): PyCrypto is not capable to serialize
        DSA keys and DER formated keys, later we need to pick better
        crypto lib.
        """
        if(generate_dto.algorithm is None or generate_dto
                .algorithm.lower() == 'rsa'):
            private_key = RSA.generate(
                generate_dto.bit_length, None, None, 65537)
        elif generate_dto.algorithm.lower() == 'dsa':
            private_key = DSA.generate(generate_dto.bit_length, None, None)
        else:
            raise c.CryptoPrivateKeyFailureException()

        public_key = private_key.publickey()

        # Note (atiwari): key wrapping format PEM only supported
        if generate_dto.algorithm.lower() == 'rsa':
            public_key, private_key = self._wrap_key(public_key, private_key,
                                                     generate_dto.passphrase)
        if generate_dto.algorithm.lower() == 'dsa':
            if generate_dto.passphrase:
                raise ValueError(u._('Passphrase not supported for DSA key'))
            public_key, private_key = self._serialize_dsa_key(public_key,
                                                              private_key)
        private_dto = self.encrypt(c.EncryptDTO(private_key),
                                   kek_meta_dto,
                                   project_id)

        public_dto = self.encrypt(c.EncryptDTO(public_key),
                                  kek_meta_dto,
                                  project_id)

        passphrase_dto = None
        if generate_dto.passphrase:
            if isinstance(generate_dto.passphrase, six.text_type):
                generate_dto.passphrase = generate_dto.passphrase.encode(
                    'utf-8')

            passphrase_dto = self.encrypt(c.EncryptDTO(generate_dto.
                                                       passphrase),
                                          kek_meta_dto,
                                          project_id)

        return private_dto, public_dto, passphrase_dto

    def supports(self, type_enum, algorithm=None, bit_length=None,
                 mode=None):
        if type_enum == c.PluginSupportTypes.ENCRYPT_DECRYPT:
            return True

        if type_enum == c.PluginSupportTypes.SYMMETRIC_KEY_GENERATION:
            return self._is_algorithm_supported(algorithm,
                                                bit_length)
        elif type_enum == c.PluginSupportTypes.ASYMMETRIC_KEY_GENERATION:
            return self._is_algorithm_supported(algorithm,
                                                bit_length)
        else:
            return False

    def _wrap_key(self, public_key, private_key,
                  passphrase):
        pkcs = 8
        key_wrap_format = 'PEM'

        private_key = private_key.exportKey(key_wrap_format, passphrase, pkcs)
        public_key = public_key.exportKey(key_wrap_format)

        return public_key, private_key

    def _serialize_dsa_key(self, public_key, private_key):

        pub_seq = asn1.DerSequence()
        pub_seq[:] = [0, public_key.p, public_key.q,
                      public_key.g, public_key.y]
        public_key = pub_seq.encode()

        prv_seq = asn1.DerSequence()
        prv_seq[:] = [0, private_key.p, private_key.q,
                      private_key.g, private_key.y, private_key.x]
        private_key = prv_seq.encode()

        return public_key, private_key

    def _is_algorithm_supported(self, algorithm=None, bit_length=None):
        """check if algorithm and bit_length combination is supported."""
        if algorithm is None or bit_length is None:
            return False

        if (algorithm.lower() in
                c.PluginSupportTypes.SYMMETRIC_ALGORITHMS and bit_length in
                c.PluginSupportTypes.SYMMETRIC_KEY_LENGTHS):
            return True
        elif (algorithm.lower() in c.PluginSupportTypes.ASYMMETRIC_ALGORITHMS
              and bit_length in c.PluginSupportTypes.ASYMMETRIC_KEY_LENGTHS):
            return True
        else:
            return False
 
