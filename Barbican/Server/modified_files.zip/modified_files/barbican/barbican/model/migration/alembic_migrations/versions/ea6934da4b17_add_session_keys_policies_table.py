"""add_session_keys_policies_table

Revision ID: ea6934da4b17
Revises: c2cf30454188
Create Date: 2017-03-21 23:15:00.646286

"""

# revision identifiers, used by Alembic.
revision = 'ea6934da4b17'
down_revision = 'c2cf30454188'

from alembic import op
import sqlalchemy as sa


def upgrade():
    ctx = op.get_context()
    con = op.get_bind()

    table_exists = ctx.dialect.has_table(con.engine, 'session_keys')
    if not table_exists:
        op.create_table(
            'session_keys',
            sa.Column('id', sa.String(length=36), nullable=False),
            sa.Column('created_at', sa.DateTime(), nullable=False),
            sa.Column('updated_at', sa.DateTime(), nullable=False),
            sa.Column('deleted_at', sa.DateTime(), nullable=True),
            sa.Column('deleted', sa.Boolean(), nullable=False),
            sa.Column('status', sa.String(length=20), nullable=False),
            sa.Column('project_id', sa.String(length=36), nullable=False),
            sa.Column('session_key', sa.Text()),
            sa.ForeignKeyConstraint(['project_id'], ['projects.id']),
            sa.PrimaryKeyConstraint('id')
        )

    table_exists = ctx.dialect.has_table(con.engine, 'project_policies')
    if not table_exists:
        op.create_table(
            'project_policies',
            sa.Column('id', sa.String(length=36), nullable=False),
            sa.Column('created_at', sa.DateTime(), nullable=False),
            sa.Column('updated_at', sa.DateTime(), nullable=False),
            sa.Column('deleted_at', sa.DateTime(), nullable=True),
            sa.Column('deleted', sa.Boolean(), nullable=False),
            sa.Column('status', sa.String(length=20), nullable=False),
            sa.Column('project_id', sa.String(length=36), nullable=False),
            sa.Column('msg3', sa.Text()),
            sa.Column('policy', sa.Integer()),
            sa.ForeignKeyConstraint(['project_id'], ['projects.id']),
            sa.PrimaryKeyConstraint('id')
        )


