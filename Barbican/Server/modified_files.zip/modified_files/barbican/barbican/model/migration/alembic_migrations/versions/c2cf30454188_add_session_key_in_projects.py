"""add_session_key_in_projects

Revision ID: c2cf30454188
Revises: d2780d5aa510
Create Date: 2016-10-17 00:54:22.401046

"""

# revision identifiers, used by Alembic.
revision = 'c2cf30454188'
down_revision = 'd2780d5aa510'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.add_column('projects', sa.Column('session_key', sa.Text))

